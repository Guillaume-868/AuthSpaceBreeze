<?php if (isset($component)) { $__componentOriginalfd1f218809a441e923395fcbf03e4272 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfd1f218809a441e923395fcbf03e4272 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfd1f218809a441e923395fcbf03e4272)): ?>
<?php $attributes = $__attributesOriginalfd1f218809a441e923395fcbf03e4272; ?>
<?php unset($__attributesOriginalfd1f218809a441e923395fcbf03e4272); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfd1f218809a441e923395fcbf03e4272)): ?>
<?php $component = $__componentOriginalfd1f218809a441e923395fcbf03e4272; ?>
<?php unset($__componentOriginalfd1f218809a441e923395fcbf03e4272); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginalc7378de9481010864cf2db9220192ee5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc7378de9481010864cf2db9220192ee5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layoutstar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layoutstar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <!-- Titre -->
    <div class="flex flex-row gap-4 bg-[#0B0D17] px-4 py-2 justify-center md:justify-start mb-10 lg:ml-20">
        <?php if (isset($component)) { $__componentOriginal5b45f10ac8a02a214896b179fba1d00c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5b45f10ac8a02a214896b179fba1d00c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nb03','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nb03'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5b45f10ac8a02a214896b179fba1d00c)): ?>
<?php $attributes = $__attributesOriginal5b45f10ac8a02a214896b179fba1d00c; ?>
<?php unset($__attributesOriginal5b45f10ac8a02a214896b179fba1d00c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5b45f10ac8a02a214896b179fba1d00c)): ?>
<?php $component = $__componentOriginal5b45f10ac8a02a214896b179fba1d00c; ?>
<?php unset($__componentOriginal5b45f10ac8a02a214896b179fba1d00c); ?>
<?php endif; ?>
        <h3 class="uppercase text-[#ffffff] md:text-left text-lg md:text-2xl mt-5 "> <?php echo e($technology->launcher); ?></h3>
    </div>

    <!-- ✅ Layout principal : flex-col en mobile, flex-row en lg -->
    <div class="flex flex-col lg:flex-row items-center justify-between gap-10">

        <!-- ✅ Image : mobile/tablette uniquement -->
        <div class="w-full mt-10 lg:hidden">
            <img src="<?php echo e(asset('images/Phone/launcher.png')); ?>" alt="moon"
                class="w-full h-auto">
        </div>


        <div class="mt-6 lg:h-screen lg:flex lg:items-center lg:hidden">
            <?php if (isset($component)) { $__componentOriginal36e525d3fdfd06bf4299788d5e19050a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal36e525d3fdfd06bf4299788d5e19050a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.numberslinks','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('numberslinks'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal36e525d3fdfd06bf4299788d5e19050a)): ?>
<?php $attributes = $__attributesOriginal36e525d3fdfd06bf4299788d5e19050a; ?>
<?php unset($__attributesOriginal36e525d3fdfd06bf4299788d5e19050a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal36e525d3fdfd06bf4299788d5e19050a)): ?>
<?php $component = $__componentOriginal36e525d3fdfd06bf4299788d5e19050a; ?>
<?php unset($__componentOriginal36e525d3fdfd06bf4299788d5e19050a); ?>
<?php endif; ?>
        </div>

        <!-- ✅ Texte + Numberslinks -->
        <section class="flex flex-col lg:flex-row justify-center items-start text-center lg:text-left overflow-y-auto gap-10">

            <!-- ✅ Numberslinks desktop -->
            <div class="hidden lg:flex lg:flex-col lg:justify-center  lg:ml-20 lg:mr-20">
                <?php if (isset($component)) { $__componentOriginal36e525d3fdfd06bf4299788d5e19050a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal36e525d3fdfd06bf4299788d5e19050a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.numberslinks','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('numberslinks'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal36e525d3fdfd06bf4299788d5e19050a)): ?>
<?php $attributes = $__attributesOriginal36e525d3fdfd06bf4299788d5e19050a; ?>
<?php unset($__attributesOriginal36e525d3fdfd06bf4299788d5e19050a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal36e525d3fdfd06bf4299788d5e19050a)): ?>
<?php $component = $__componentOriginal36e525d3fdfd06bf4299788d5e19050a; ?>
<?php unset($__componentOriginal36e525d3fdfd06bf4299788d5e19050a); ?>
<?php endif; ?>
            </div>

            <!-- ✅ Bloc texte -->
            <div class="flex flex-col justify-center items-center lg:items-start text-center lg:text-left">
                <span class="text-[#D0D6F9] uppercase text-2xl"> <?php echo e($technology->starships); ?> </span>
                <h1 class="text-white uppercase text-4xl mt-2"> <?php echo e(__('technology.subtitle')); ?></h1>
                <p class="text-[#D0D6F9] text-center lg:text-left mt-10 mb-10 lg:max-w-xl">
                <?php echo e($technology->description); ?>

                </p>
            </div>

        </section>

        <!-- ✅ Image version PC -->
        <div class="hidden lg:flex items-center justify-center">
            <img src="<?php echo e(asset('images/Deskstop/lanceur.png')); ?>" alt="launcher"
                class="w-full h-auto max-w-md">
        </div>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc7378de9481010864cf2db9220192ee5)): ?>
<?php $attributes = $__attributesOriginalc7378de9481010864cf2db9220192ee5; ?>
<?php unset($__attributesOriginalc7378de9481010864cf2db9220192ee5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc7378de9481010864cf2db9220192ee5)): ?>
<?php $component = $__componentOriginalc7378de9481010864cf2db9220192ee5; ?>
<?php unset($__componentOriginalc7378de9481010864cf2db9220192ee5); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\TPSpaceTourism\AuthSpaceBreeze\resources\views/Space/Starships/launcher.blade.php ENDPATH**/ ?>