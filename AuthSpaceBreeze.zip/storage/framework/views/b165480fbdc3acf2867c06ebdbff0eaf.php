<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Modifier la planète : <?php echo e($planet->name_fr); ?> <?php $__env->endSlot(); ?>

    <h1 class="text-3xl font-bold text-center mt-6">Modifier la planète : <?php echo e($planet->name_fr); ?></h1>

    <div class="flex justify-center mt-10">
        <form action="<?php echo e(route('planets.update', $planet)); ?>" method="POST" class="flex flex-col w-96 rounded border border-gray-300 p-6 bg-white shadow-md">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <h4 class="mt-5 text-center font-bold">🇫🇷 Français</h4>
            <input type="text" name="name_fr" value="<?php echo e($planet->name_fr); ?>" required placeholder="Nom (FR)" class="mb-2 mt-4 p-2 border rounded">
            <input type="text" name="subtitle_fr" value="<?php echo e($planet->subtitle_fr); ?>" placeholder="Sous-titre (FR)" class="mb-2 p-2 border rounded">
            <textarea name="description_fr" placeholder="Description (FR)" class="mb-2 p-2 border rounded"><?php echo e($planet->description_fr); ?></textarea>
            <input type="text" name="distance_fr" value="<?php echo e($planet->distance_fr); ?>" placeholder="Distance (FR)" class="mb-2 p-2 border rounded">
            <input type="text" name="duration_fr" value="<?php echo e($planet->duration_fr); ?>" placeholder="Durée (FR)" class="mb-4 p-2 border rounded">

            <h4 class="mt-5 text-center font-bold">🇬🇧 English</h4>
            <input type="text" name="name_en" value="<?php echo e($planet->name_en); ?>" required placeholder="Name (EN)" class="mb-2 mt-4 p-2 border rounded">
            <input type="text" name="subtitle_en" value="<?php echo e($planet->subtitle_en); ?>" placeholder="Subtitle (EN)" class="mb-2 p-2 border rounded">
            <textarea name="description_en" placeholder="Description (EN)" class="mb-2 p-2 border rounded"><?php echo e($planet->description_en); ?></textarea>
            <input type="text" name="distance_en" value="<?php echo e($planet->distance_en); ?>" placeholder="Distance (EN)" class="mb-2 p-2 border rounded">
            <input type="text" name="duration_en" value="<?php echo e($planet->duration_en); ?>" placeholder="Duration (EN)" class="mb-4 p-2 border rounded">

            <div class="text-center mt-4">
                <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg shadow-md transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2">
                    Mettre à jour
                </button>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\TPSpaceTourism\AuthSpaceBreeze\resources\views/Space/PlanetsCrud/edit.blade.php ENDPATH**/ ?>