<?php if (isset($component)) { $__componentOriginalfd1f218809a441e923395fcbf03e4272 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfd1f218809a441e923395fcbf03e4272 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfd1f218809a441e923395fcbf03e4272)): ?>
<?php $attributes = $__attributesOriginalfd1f218809a441e923395fcbf03e4272; ?>
<?php unset($__attributesOriginalfd1f218809a441e923395fcbf03e4272); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfd1f218809a441e923395fcbf03e4272)): ?>
<?php $component = $__componentOriginalfd1f218809a441e923395fcbf03e4272; ?>
<?php unset($__componentOriginalfd1f218809a441e923395fcbf03e4272); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginalc7378de9481010864cf2db9220192ee5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc7378de9481010864cf2db9220192ee5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layoutstar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layoutstar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-screen-xl mx-auto px-4"> <!-- ✅ Conteneur central aligné -->

        <!-- ✅ Titre -->
        <div class="order-1 md:order-1 lg:order-1 w-full md:mt-10">
            <div class="flex flex-row items-center gap-4 bg-[#0B0D17] py-2 justify-center md:justify-start mb-10 lg:mb-20 w-full lg:hidden">
                <?php if (isset($component)) { $__componentOriginale953b91bdf597b2a1006a73acb1a5c5c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale953b91bdf597b2a1006a73acb1a5c5c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nb02','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nb02'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale953b91bdf597b2a1006a73acb1a5c5c)): ?>
<?php $attributes = $__attributesOriginale953b91bdf597b2a1006a73acb1a5c5c; ?>
<?php unset($__attributesOriginale953b91bdf597b2a1006a73acb1a5c5c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale953b91bdf597b2a1006a73acb1a5c5c)): ?>
<?php $component = $__componentOriginale953b91bdf597b2a1006a73acb1a5c5c; ?>
<?php unset($__componentOriginale953b91bdf597b2a1006a73acb1a5c5c); ?>
<?php endif; ?>
                <h3 class="uppercase text-white text-center md:text-left text-lg md:text-2xl lg:hidden ">
                <?php echo e(__('crew.subtitle')); ?>

                </h3>
            </div>
        </div>

        <!-- ✅ Bloc principal responsive -->
        <div class="flex flex-col md:flex-col-reverse lg:flex-row-reverse items-center justify-center gap-10">



            <!-- Texte -->
            <section class="flex flex-col justify-center items-center md:items-center lg:items-start text-center lg:text-left overflow-y-auto order-3 lg:order-1">
                <div class="hidden lg:block lg:flex lg:gap-5 lg:mb-30">
                    <?php if (isset($component)) { $__componentOriginale953b91bdf597b2a1006a73acb1a5c5c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale953b91bdf597b2a1006a73acb1a5c5c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nb02','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('nb02'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale953b91bdf597b2a1006a73acb1a5c5c)): ?>
<?php $attributes = $__attributesOriginale953b91bdf597b2a1006a73acb1a5c5c; ?>
<?php unset($__attributesOriginale953b91bdf597b2a1006a73acb1a5c5c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale953b91bdf597b2a1006a73acb1a5c5c)): ?>
<?php $component = $__componentOriginale953b91bdf597b2a1006a73acb1a5c5c; ?>
<?php unset($__componentOriginale953b91bdf597b2a1006a73acb1a5c5c); ?>
<?php endif; ?>
                    <h3 class="uppercase text-white text-left text-lg md:text-2xl hidden lg:block">
                    <?php echo e(__('crew.subtitle')); ?>

                    </h3>
                </div>
               
                <span class="text-gray-700 uppercase text-lg md:text-2xl"><?php echo e($crew->fonction); ?></span>
                <h1 class="text-white uppercase text-lg md:text-2xl">douglas hurley</h1>
                <p class="text-[#D0D6F9] mt-10 text-lg md:text-2xl lg:max-w-xl">
                    <?php echo e($crew->description); ?>

                </p>

                <!-- Roundlink (PC) -->
                <div class="hidden lg:block mt-40">
                    <?php if (isset($component)) { $__componentOriginalfab67421ff607c3727fdc1ac9e336b41 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfab67421ff607c3727fdc1ac9e336b41 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.roundlink','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('roundlink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfab67421ff607c3727fdc1ac9e336b41)): ?>
<?php $attributes = $__attributesOriginalfab67421ff607c3727fdc1ac9e336b41; ?>
<?php unset($__attributesOriginalfab67421ff607c3727fdc1ac9e336b41); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfab67421ff607c3727fdc1ac9e336b41)): ?>
<?php $component = $__componentOriginalfab67421ff607c3727fdc1ac9e336b41; ?>
<?php unset($__componentOriginalfab67421ff607c3727fdc1ac9e336b41); ?>
<?php endif; ?>
                </div>
            </section>

            <!-- Image + Roundlink Mobile/Tablette -->
            <section>
                <!-- Roundlink tablette -->
                <div class="hidden md:block mt-6 mb-10 lg:hidden">
                    <?php if (isset($component)) { $__componentOriginalfab67421ff607c3727fdc1ac9e336b41 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfab67421ff607c3727fdc1ac9e336b41 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.roundlink','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('roundlink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfab67421ff607c3727fdc1ac9e336b41)): ?>
<?php $attributes = $__attributesOriginalfab67421ff607c3727fdc1ac9e336b41; ?>
<?php unset($__attributesOriginalfab67421ff607c3727fdc1ac9e336b41); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfab67421ff607c3727fdc1ac9e336b41)): ?>
<?php $component = $__componentOriginalfab67421ff607c3727fdc1ac9e336b41; ?>
<?php unset($__componentOriginalfab67421ff607c3727fdc1ac9e336b41); ?>
<?php endif; ?>
                </div>

                <!-- Image mobile / tablette -->
                <div class="flex flex-col items-center justify-center lg:hidden">
                    <img src="<?php echo e(asset('images/Phone/leaderdouglass.png')); ?>" alt="commander" class="w-80 h-60 md:w-80 h-80 mx-auto">
                </div>

                <!-- Image PC -->
                <div class="hidden lg:flex flex-col items-center justify-center">
                    <img src="<?php echo e(asset('images/Deskstop/leaderdouglass.png')); ?>" alt="commander" class="mx-auto">
                </div>

                <!-- Roundlink mobile -->
                <div class="block mt-6 lg:hidden md:hidden">
                    <?php if (isset($component)) { $__componentOriginalfab67421ff607c3727fdc1ac9e336b41 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfab67421ff607c3727fdc1ac9e336b41 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.roundlink','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('roundlink'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfab67421ff607c3727fdc1ac9e336b41)): ?>
<?php $attributes = $__attributesOriginalfab67421ff607c3727fdc1ac9e336b41; ?>
<?php unset($__attributesOriginalfab67421ff607c3727fdc1ac9e336b41); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfab67421ff607c3727fdc1ac9e336b41)): ?>
<?php $component = $__componentOriginalfab67421ff607c3727fdc1ac9e336b41; ?>
<?php unset($__componentOriginalfab67421ff607c3727fdc1ac9e336b41); ?>
<?php endif; ?>
                </div>
            </section>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc7378de9481010864cf2db9220192ee5)): ?>
<?php $attributes = $__attributesOriginalc7378de9481010864cf2db9220192ee5; ?>
<?php unset($__attributesOriginalc7378de9481010864cf2db9220192ee5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc7378de9481010864cf2db9220192ee5)): ?>
<?php $component = $__componentOriginalc7378de9481010864cf2db9220192ee5; ?>
<?php unset($__componentOriginalc7378de9481010864cf2db9220192ee5); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\TPSpaceTourism\AuthSpaceBreeze\resources\views/Space/Crew/commandant.blade.php ENDPATH**/ ?>