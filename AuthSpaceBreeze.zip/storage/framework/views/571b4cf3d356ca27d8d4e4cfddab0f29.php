<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes tâches</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-[#0B0D17]">

    <?php if (isset($component)) { $__componentOriginal27dc6277b85491d47ded5f7c284c1a13 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal27dc6277b85491d47ded5f7c284c1a13 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.language-selector','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('language-selector'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal27dc6277b85491d47ded5f7c284c1a13)): ?>
<?php $attributes = $__attributesOriginal27dc6277b85491d47ded5f7c284c1a13; ?>
<?php unset($__attributesOriginal27dc6277b85491d47ded5f7c284c1a13); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal27dc6277b85491d47ded5f7c284c1a13)): ?>
<?php $component = $__componentOriginal27dc6277b85491d47ded5f7c284c1a13; ?>
<?php unset($__componentOriginal27dc6277b85491d47ded5f7c284c1a13); ?>
<?php endif; ?>
    <div class="container mx-auto">
        <!-- <h1 class="text-2xl font-bold mb-4"></h1> -->
        <?php echo e($slot); ?>

    </div>
</body>
</html><?php /**PATH C:\laragon\www\TPSpaceTourism\AuthSpaceBreeze\resources\views/components/layout.blade.php ENDPATH**/ ?>