<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Ajouter une planète
     <?php $__env->endSlot(); ?>

    <h1 class="flex justify-center mt-6 text-4xl font-bold">
        Ajouter une planète
    </h1>

    <div class="flex justify-center">
        <form 
            action="<?php echo e(route($type . '.store')); ?>" 
            method="POST" 
            class="flex-col w-100 rounded-sm mt-20 border-radius border border-black p-4"
        >
            <?php echo csrf_field(); ?>
         
            <!-- 🇬🇧 Partie anglaise -->
            <h4 class="mt-5 text-center font-bold">🇬🇧 English</h4>

                <input type="text" name="name_en" placeholder="Name (EN)" required class="form-control mb-2 mt-4">
                <input type="text" name="subtitle_en" placeholder="Subtitle (EN)" class="form-control mb-2">
                <input type="text" name="distance_en" placeholder="Distance (EN)" class="form-control mb-2">
                <input type="text" name="duration_en" placeholder="Duration (EN)" class="form-control mb-4">
                <textarea name="description_en" placeholder="Description (EN)" class="form-control mb-2 w-80"></textarea>

            <div class="text-center">
                <button 
                    type="submit" 
                    class="bg-blue-500 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-lg shadow-md transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2"
                >
                    Enregistrer
                </button>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\TPSpaceTourism\AuthSpaceBreeze\resources\views/Space/PlanetsCrud/create.blade.php ENDPATH**/ ?>