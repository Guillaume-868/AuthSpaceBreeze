<span class="text-center uppercase bg-[#0B0D17] text-gray-400 text-lg md:text-2xl ">02</span>

<?php /**PATH C:\laragon\www\TPSpaceTourism\AuthSpaceBreeze\resources\views/components/nb02.blade.php ENDPATH**/ ?>