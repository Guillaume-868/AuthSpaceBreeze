<?php if (isset($component)) { $__componentOriginalfd1f218809a441e923395fcbf03e4272 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfd1f218809a441e923395fcbf03e4272 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfd1f218809a441e923395fcbf03e4272)): ?>
<?php $attributes = $__attributesOriginalfd1f218809a441e923395fcbf03e4272; ?>
<?php unset($__attributesOriginalfd1f218809a441e923395fcbf03e4272); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfd1f218809a441e923395fcbf03e4272)): ?>
<?php $component = $__componentOriginalfd1f218809a441e923395fcbf03e4272; ?>
<?php unset($__componentOriginalfd1f218809a441e923395fcbf03e4272); ?>
<?php endif; ?>

<?php if (isset($component)) { $__componentOriginalc7378de9481010864cf2db9220192ee5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc7378de9481010864cf2db9220192ee5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layoutstar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layoutstar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex flex-col lg:flex-row items-center justify-center gap-10 px-4 md:px-20 mb-10">
        <!-- Titre + image à gauche -->
        <div class="flex flex-col items-center w-full lg:w-1/2 gap-6">
            <h3 class="uppercase text-[#ffffff] text-center md:text-2xl md:whitespace-nowrap whitespace-nowrap md:mt-10 text-[#D0D6F9]">
                <?php echo e(__('planet.subtitle')); ?>

            </h3>

            <img
                src="<?php echo e(Storage::url($planet->image->path ?? 'moon.png')); ?>"
                alt="<?php echo e($planet->name); ?>"
                class="w-40 h-40 md:w-60 md:h-60 lg:w-[445px] lg:h-[445px] mx-auto" />


        </div>

        <!-- Colonne droite : texte -->
        <div class="w-full lg:w-1/2 text-center lg:text-left">
            <?php if (isset($component)) { $__componentOriginaldeeb11f85b94c5e70a23b9fcc154dd82 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldeeb11f85b94c5e70a23b9fcc154dd82 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.planets','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('planets'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldeeb11f85b94c5e70a23b9fcc154dd82)): ?>
<?php $attributes = $__attributesOriginaldeeb11f85b94c5e70a23b9fcc154dd82; ?>
<?php unset($__attributesOriginaldeeb11f85b94c5e70a23b9fcc154dd82); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldeeb11f85b94c5e70a23b9fcc154dd82)): ?>
<?php $component = $__componentOriginaldeeb11f85b94c5e70a23b9fcc154dd82; ?>
<?php unset($__componentOriginaldeeb11f85b94c5e70a23b9fcc154dd82); ?>
<?php endif; ?>

            <h1 class="uppercase text-white text-4xl md:text-8xl mt-10 md:mt-5 text-center lg:text-left"> <?php echo e($planet->name); ?> </h1>

            <p class="text-[#D0D6F9] text-base md:text-lg lg:text-xl mt-5 max-w-xl mx-auto lg:mx-0 text-center lg:text-left">
                <?php echo e($planet->description); ?>

            </p>

            <!-- Stats (distance et durée) -->
            <section class="mt-10 text-white flex flex-col md:flex-row items-center justify-center gap-10 md:gap-20 lg:justify-start text-center lg:text-left">
                <div>
                    <h3 class="uppercase mb-2 text-[#D0D6F9]">distance</h3>
                    <p class="text-white uppercase text-2xl"><?php echo e($planet->distance); ?></p>
                </div>
                <div>
                    <h3 class="uppercase mb-2 text-[#D0D6F9]">durée</h3>
                    <p class="text-white uppercase text-2xl"><?php echo e($planet->duration); ?></p>
                </div>
            </section>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc7378de9481010864cf2db9220192ee5)): ?>
<?php $attributes = $__attributesOriginalc7378de9481010864cf2db9220192ee5; ?>
<?php unset($__attributesOriginalc7378de9481010864cf2db9220192ee5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc7378de9481010864cf2db9220192ee5)): ?>
<?php $component = $__componentOriginalc7378de9481010864cf2db9220192ee5; ?>
<?php unset($__componentOriginalc7378de9481010864cf2db9220192ee5); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\TPSpaceTourism\AuthSpaceBreeze\resources\views/Space/Planets/moon.blade.php ENDPATH**/ ?>