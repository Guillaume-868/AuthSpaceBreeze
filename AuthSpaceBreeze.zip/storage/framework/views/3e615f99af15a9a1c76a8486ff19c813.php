<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Liste des planètes <?php $__env->endSlot(); ?>

    <h1 class="text-3xl font-bold mb-6 mt-10 ml-10">🌍 Liste des planètes</h1>

    <!-- Bouton d’ajout -->
    <a href="<?php echo e(route('planets.create')); ?>"
       class="ml-10 bg-blue-500 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded mb-4 inline-block">
        + Ajouter une planète
    </a>

    <!-- Table en anglais -->
    <div class="overflow-x-auto mt-20 px-10 mb-10">
        <h2 class="text-2xl font-semibold mb-4 text-center">🇬🇧 Planets (English)</h2>

        <table class="min-w-full bg-white border border-gray-200 shadow-md rounded text-center">
            <thead class="bg-gray-100">
                <tr>
                    <th class="py-2 px-4 border-b">Name</th>
                    <th class="py-2 px-4 border-b">Subtitle</th>
                    <th class="py-2 px-4 border-b">Distance</th>
                    <th class="py-2 px-4 border-b">Duration</th>
                    <th class="py-2 px-4 border-b">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $planets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $planet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-gray-50">
                        <td class="py-2 px-4 border-b"><?php echo e($planet->name); ?></td>
                        <td class="py-2 px-4 border-b"><?php echo e($planet->subtitle); ?></td>
                        <td class="py-2 px-4 border-b"><?php echo e($planet->distance); ?></td>
                        <td class="py-2 px-4 border-b"><?php echo e($planet->duration); ?></td>
                        <td class="py-2 px-4 border-b space-x-2">
                            <a href="<?php echo e(route('planets.edit', $planet)); ?>"
                               class="bg-yellow-400 hover:bg-yellow-500 text-white py-1 px-4 rounded inline-block w-24 text-center">
                                Edit
                            </a>

                            <form action="<?php echo e(route('planets.destroy', $planet)); ?>" method="POST" class="inline-block">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"
                                        class="bg-red-500 hover:bg-red-600 text-white py-1 px-4 rounded inline-block w-24 text-center">
                                    Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\TPSpaceTourism\AuthSpaceBreeze\resources\views/Space/PlanetsCrud/index.blade.php ENDPATH**/ ?>