<nav class="flex justify-center space-x-4">
    <a href="#" class="w-3 h-3 rounded-full bg-gray-400 flex items-center justify-center hover:bg-white transition">
    </a>
    <a href="#" class="w-3 h-3 rounded-full bg-gray-400  flex items-center justify-center hover:bg-white transition">     
    </a>
    <a href="#" class="w-3 h-3 rounded-full bg-gray-400 flex items-center justify-center hover:bg-white transition"> 
    </a>
    <a href="#" class="w-3 h-3 rounded-full bg-gray-400 flex items-center justify-center hover:bg-white transition"> 
    </a>
</nav><?php /**PATH C:\laragon\www\TPSpaceTourism\AuthSpaceBreeze\resources\views/components/roundlink.blade.php ENDPATH**/ ?>