<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('technologies', function (Blueprint $table) {
            $table->id();  // ✅ PRIMARY KEY automatique

            // La technlogies appartient à une image → crew.image_id pointe vers images.id
            $table->foreignId('image_id')->nullable()
                ->constrained('images')
                ->nullOnDelete(); 

            $table->timestamps();
            $table->string('starships_fr', 50);
            $table->string('starships_en', 50);
            $table->text('description_fr');
            $table->text('description_en');
            $table->string('launcher_fr', 20)->nullable();
            $table->string('launcher_en', 20)->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('technologie');
    }
};
